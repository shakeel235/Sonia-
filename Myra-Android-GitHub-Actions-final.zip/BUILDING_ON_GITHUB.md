# Build Myra APKs with GitHub Actions

This repository is already arranged for direct upload. `app/`, `gradle/`, `build.gradle`, `settings.gradle`, `gradlew`, and `.github/` are at the repository root.

## Upload

1. Create a GitHub repository.
2. Extract this ZIP.
3. Upload the extracted contents, not the enclosing folder.
4. Confirm `.github/workflows/build.yml` is present at the repository root.
5. Commit and push to `main`.

## Optional Gemini key

For voice AI, add a repository secret named `GEMINI_API_KEY` under **Settings → Secrets and variables → Actions**. The workflow creates `local.properties` during the build; it is not committed.

## Build

Open **Actions → Build Myra APKs → Run workflow**. The workflow installs JDK 17, Android SDK Platform 36, Build Tools 36.0.0, and Gradle 8.2, then builds both variants.

Download the `myra-apks` artifact from the completed run:

```text
app-debug.apk
app-release.apk
```

The project currently uses `minSdk 29`, so it targets Android 10 and newer. The release variant currently uses the debug signing configuration from the supplied source; configure a private release keystore before public distribution.
